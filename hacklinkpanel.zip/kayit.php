

<?php
session_start();

if( isset($_SESSION['user_id']) ){
	header("Location: index.php");
}

require 'baglantilar/database.php';
$cfg = include('ayarlar/ayar.php');

$bilgiver = '';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}



if(!empty(htmlspecialchars($_POST['kullaniciadi'])) && !empty(htmlspecialchars($_POST['sifre'])) && !empty(htmlspecialchars($_POST['tekrar_sifre']))):
	if(htmlspecialchars($_POST['sifre']) != htmlspecialchars($_POST['tekrar_sifre']))
	{
		$bilgiver = "<div class='alert alert-danger'>Yazdığınız Şifreler Eşleşmemektedir.</div>";
	}
	else if(!filter_var(htmlspecialchars($_POST['kullaniciadi'])))
	{
		$bilgiver = "<div class='alert alert-danger'><button type='button' class='close' data-dismiss='alert'>×</button><strong>Kullanıcı Adınızı Kontrol Ediniz..</div></strong>";
	}
	else
	{
	
		$veriyolla = $conn->prepare('SELECT id,kullaniciadi,password FROM kullanicilar WHERE kullaniciadi = :kullaniciadi');
		$veriyolla->bindParam(':kullaniciadi', htmlspecialchars($_POST['kullaniciadi']));
		$veriyolla->execute();
		$sonucumuz = $veriyolla->fetch(PDO::FETCH_ASSOC);

		if( count($sonucumuz) > 0 && $sonucumuz){
			$bilgiver = "<div class='alert alert-danger'><button type='button' class='close' data-dismiss='alert'>×</button><strong>Yazdığınız Kullanıcı Adı Zaten Sistemde Mevcuttur..</div></strong>";
		}
		else
		{
			
			

		
		
			$pass = password_hash($_POST['sifre'], PASSWORD_BCRYPT);
			$kullanici =  htmlspecialchars($_POST['kullaniciadi']);
			$isim = htmlspecialchars($_POST['isim']);
			$email = htmlspecialchars($_POST['email']);
			$kredi = '0';
			$var = $ip;
			$s = $conn->prepare('SELECT * FROM kullanicilar WHERE iplog = :iplog');
		$s->bindParam(':iplog', $var);
		$s->execute();
		$ss = $s->fetch(PDO::FETCH_ASSOC);
			
			if(count($ss) > 0 && $ss){
				$bilgiver = "<div class='alert alert-danger'><button type='button' class='close' data-dismiss='alert'>×</button><strong>Hata:</strong> Çoklu Üyelik Kesinlikle Yasaktır!</div>";
			}else{
			
			$sql = "INSERT INTO kullanicilar (kullaniciadi, password, isim, email, kredi, iplog) VALUES (:kullaniciadi, :password, :isim, :email, :kredi, :iplog)";
			$stmt = $conn->prepare($sql);

			$stmt->bindParam(':kullaniciadi', $kullanici);
			$stmt->bindParam(':password', $pass);
			$stmt->bindParam(':isim', $isim);
			$stmt->bindParam(':email', $email);
			$stmt->bindParam(':kredi', $kredi);
			$stmt->bindParam(':iplog', $var);
			if( $stmt->execute() ):
				$bilgiver = '<meta http-equiv="refresh" content="2; URL=giris.php"> <div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Başarılı:</strong> Hesabınız Başarıyla Oluşturuldu!</div>';
			else:
				$bilgiver = "<div class='alert alert-danger'>Sunucuya Bağlanılamadı Lütfen Daha Sonra Tekrar Deneyiniz..</div>";
			endif;
			}
		}
	}
	

endif;


				  
?>

  
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kayit Ol</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="giristasarim/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="giristasarim/bootstrap/giristasarim/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="giristasarim/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="giristasarim/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="giristasarim/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="giristasarim/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="giristasarim/animsition/giristasarim/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="giristasarim/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="giristasarim/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="giristasarim/util.css">
	<link rel="stylesheet" type="text/css" href="giristasarim/main.css">
<!--===============================================================================================-->
</head>
<body>
	
<div class="limiter">
		<div class="container-login100" style="background-image: url('giristasarim/images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<span class="login100-form-title p-b-49">
						Kayıt Ol
					</span>
					
					<div class="message">		
		  <?php if(!empty($mesajgoster)): ?>
		<p><?= $mesajgoster ?></p>
	<?php endif; ?>
		  </div>
<form action="" method="post">
					<div class="wrap-input100 validate-input m-b-23" data-validate = "Gerekli">
						<span class="label-input100">E-Posta Adresiniz</span>
						<input class="input100" type="text" name="email" placeholder="E-Posta Adresiniz">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>
					
					<div class="wrap-input100 validate-input m-b-23" data-validate = "Gerekli">
						<span class="label-input100">Kullanici Adiniz</span>
						<input class="input100" type="text" name="kullaniciadi" placeholder="Kullanici Adiniz">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>
					
					<div class="wrap-input100 validate-input m-b-23" data-validate = "Gerekli">
						<span class="label-input100">İsminiz</span>
						<input class="input100" type="text" name="isim" placeholder="İsminiz">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Gerekli 2">
						<span class="label-input100">Şifreniz</span>
						<input class="input100" type="password" name="sifre" placeholder="Şifreniz">
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<br><div class="wrap-input100 validate-input" data-validate="Gerekli 2">
						<span class="label-input100">Tekrar Şifreniz</span>
						<input class="input100" type="password" name="tekrar_sifre" placeholder="Tekrar Şifreniz">
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="text-right p-t-8 p-b-31">
						
					</div>
					
					<div class="text-right p-t-8 p-b-31">
					
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit">
								Kayıt Ol
							</button>
						</div>
					</div>

				

					<div class="flex-col-c p-t-155">
						

						<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit">
								<a href="giris.php" style="
    color: #fff;
">Hemen Giriş Yap !
							</button>
							
							
							

						</div>
					</div>
					
					

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="giristasarim/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="giristasarim/animsition/giristasarim/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="giristasarim/bootstrap/giristasarim/js/popper.js"></script>
	<script src="giristasarim/bootstrap/giristasarim/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="giristasarim/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="giristasarim/daterangepicker/moment.min.js"></script>
	<script src="giristasarim/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="giristasarim/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="giristasarim/js/main.js"></script>

</body>
</html> 