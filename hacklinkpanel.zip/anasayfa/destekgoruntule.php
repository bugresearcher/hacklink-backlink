<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>


<?php 

$vericek = $conn -> prepare("SELECT * FROM destektalepleri where id = :id");
$vericek->bindParam(':id', $_GET['numara']);
$vericek-> execute();
$veriyigoster = $vericek -> fetch(PDO::FETCH_ASSOC);
?>

   <div class="col-md-12">
              

     
	 <body class="theme-purple">
    <div class="col-lg-15 col-md-15 col-sm-15">
        <div class="card">
            <div class="header">

     <div class="panel panel-default m-t-11" style="">

      <div class="panel-heading">Baslikli Destek Talebiniz (NOT DESTEK İSLEMLERİ TEK TALEPLİKTİR HER HANGİ SORU ICIN TEKRAR OLUSTURUN)</div>
      <div class="panel-body">

   

    
         <br> <div class="message"></div>

          <div class="form-group">
		  <form action="" method="post">
            <label>Basliginiz</label>
            <input type="text" name="Basliginiz" id="Basliginiz" class="form-control" value="<?php echo $veriyigoster['baslik']; ?>" autocapitalize="off" readonly>
          </div>

       
    
      
<div class="form-group">
            <label>Sorunuz</label>
            <input type="text" name="Sorunuz" id="Sorunuz" class="form-control" value="<?php echo $veriyigoster['kullanicicevap']; ?>" autocapitalize="off" readonly>
          </div>
        

       
       

          <div class="form-group">
            <label>Yönetici Cevabı</label>
            <input type="text" name="yoneticicevap" id="yoneticicevap" class="form-control" value="<?php echo $veriyigoster['yoneticicevap']; ?>" autocapitalize="off" readonly>
          </div>



          <div class="form-group">
		  
		  <a href="?sayfa=destektalepleri" class="btn btn-primary btn-round">Destek Taleplerine Geri Dön ! </a>
           

          </div>
        </form>

       </div> 