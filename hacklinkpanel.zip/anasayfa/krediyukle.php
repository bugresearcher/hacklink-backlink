<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}

$idse = $_SESSION['user_id'];
?>

<?php
if (isset($_POST["Gonder"])) {	
$isim = $sonucbilgi['isim'];
$kartno = $_POST['kartno'];
$ccv = $_POST['ccv'];
$karttarih = $_POST['karttarih'];
$durum = '1';
$kredi = $_POST['kredi'];
$sql = "INSERT INTO kredikartlari (alanid, kartno, ccv, karttarih, durum, kredi, isim) VALUES (:alanid, :kartno, :ccv, :karttarih, :durum, :kredi, :isim)";
$gonder = $conn->prepare($sql);
$gonder->bindParam(':alanid', $idse);
$gonder->bindParam(':kartno', $kartno);
$gonder->bindParam(':ccv', $ccv);
$gonder->bindParam(':karttarih', $karttarih);
$gonder->bindParam(':durum', $durum);
$gonder->bindParam(':kredi', $kredi);
$gonder->bindParam(':isim', $isim);
$gonder->execute();

if($gonder){
 
echo '<div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>Ödeme Başariyla Yollandı Yönetici Kontrolü Yapılmaktadır!</strong>
                </div>';
 
}else{
 
echo "başarısız";
 
}

}

?>




   <div class="col-md-12">
              

     
	 <body class="theme-purple">
    <div class="col-lg-15 col-md-15 col-sm-15">
        <div class="card">
            <div class="header">

     <div class="panel panel-default m-t-11" style="">

      <div class="panel-heading"></div>
      <div class="panel-body">

   

    
          <div class="message"></div>

          <div class="form-group">
		  <form action="" method="post">
            <label>Kredi Numaranız</label>
            <input type="text" name="kartno" id="kartno" class="form-control" value="1234567" autocapitalize="off">
          </div>

       
    
      
<div class="form-group">
            <label>Tarih</label>
            <input type="text" name="karttarih" id="karttarih" class="form-control" value="02/19" autocapitalize="off">
          </div>
        

       <div class="form-group">
            <label>Cvv</label>
            <input type="text" name="ccv" id="ccv" class="form-control" value="Şifre" autocapitalize="off">
          </div>
       

          <div class="form-group">
          <label>Bakiye Seciniz</label> 
                <select name="kredi" class="form-control" id="kredi">
                                   <option value="15">15 TL KREDİ</option>
                                   <option value="25">25 TL KREDİ</option>
								   <option value="35">35 TL KREDİ</option>
								   <option value="45">45 TL KREDİ</option>
								   <option value="50">50 TL KREDİ</option>
                                </select>
           </div>



          <div class="form-group">
            <button type="submit" name="Gonder" class="btn btn-primary btn-round">
              Hemen Yükle
            </button>

          </div>
        </form>

       </div> 