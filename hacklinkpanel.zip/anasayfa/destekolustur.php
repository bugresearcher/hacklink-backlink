<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>







<?php
if (isset($_POST["Gonder"])) {	
$gonderenid = $_SESSION['user_id'];
$isim = $sonucbilgi['isim'];
$baslik = $_POST['baslik'];
$kullanicicevap = $_POST['kullanicicevap'];
$yoneticicevap = 'Yonetici Mesaji Bekleniyor !';
$durum = '1';
$sql = "INSERT INTO destektalepleri (alanid, baslik, isim, kullanicicevap, yoneticicevap, durum) VALUES (:alanid, :baslik, :isim, :kullanicicevap, :yoneticicevap, :durum)";
$gonder = $conn->prepare($sql);
$gonder->bindParam(':alanid', $gonderenid);
$gonder->bindParam(':baslik', $baslik);
$gonder->bindParam(':isim', $isim);
$gonder->bindParam(':kullanicicevap', $kullanicicevap);
$gonder->bindParam(':yoneticicevap', $yoneticicevap);
$gonder->bindParam(':durum', $durum);
$gonder->execute();
if($gonder){
 
echo '<meta http-equiv="refresh" content="2;URL=?sayfa=destektalepleri"><div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>Destek Talebi Başari İle Oluşturuldu!</strong>
                </div>';
 
}else{
 
echo "başarısız";
 
}
}
?>
   <div class="col-md-12">
              

     
	 <body class="theme-purple">
    <div class="col-lg-15 col-md-15 col-sm-15">
        <div class="card">
            <div class="header">

     <div class="panel panel-default m-t-11" style="">

      <div class="panel-body">

   

    
          <div class="message"></div>

          <div class="form-group">
		  <form action="" method="post">
            <label>Basliginiz</label>
            <input type="text" name="baslik" id="baslik" class="form-control" value="Örnek: Merhaba Destek Sağlarmısınız." autocapitalize="off">
          </div>

       
    
      
<div class="form-group">
            <label>Sorunuz</label>
            <input type="text" name="kullanicicevap" id="kullanicicevap" class="form-control" value="Örnek: Merhaba Nasıl Satın Alacağım." autocapitalize="off">
          </div>
       




          <div class="form-group">
            <button type="submit" name="Gonder" class="btn btn-primary btn-round">
              Hemen Destek Talebi Oluştur !
            </button>

          </div>
        </form>

       </div> 
	   
	   
