<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>


     <?php

if (isset($_POST["Gonder"])) {
    
    include("baglantilar/phpQuery-onefile.php");

    $ulkemiz = $_POST['ulke'];
    $alanadi = $_POST['alanadi'];
    $anahtarkelimeler = $_POST['anahtarkelime'];
    $sonuclar = 50;

    $siramiz = 0;
    $linkler = Array();
    $sayfalar = ceil($sonuclar / 10);
    for($p = 0; $p < $sayfalar; $p++){
        $baslat = $p * 10;
        $linkicektir = "https://www.google.com/search?hl=".$ulkemiz."&output=search&start=".$baslat."&q=".urlencode($anahtarkelimeler);
        $html = file_get_contents($linkicektir);

        $doc = phpQuery::newDocument($html);

        foreach($doc['#ires cite'] as $yolla){
            $siramiz++;
            $linkal = $yolla->nodeValue;
            $linkler[] = "[".$siramiz."] => ".$linkal;
            if(stripos($linkal, $alanadi) !== false){
                break(2);
            }
        }
    }


    $siraverisi = "<div class='alert alert-dismissible alert-danger'>
                        <button type='button' class='close' data-dismiss='alert'>&times;</button>
                        <strong>Ülkeniz : ".$ulkemiz." - Alan Adiniz: ".$alanadi." - Anahtar Kelimeniz:".$anahtarkelimeler." - Sıranız: ".$siramiz."</strong>
                </div>";

}
?>


   <div class="col-md-12">
              
  <?php if(!empty($siraverisi)): ?>
		<p><?= $siraverisi ?></p>
	<?php endif; ?>
     
	 <body class="theme-purple">
    <div class="col-lg-15 col-md-15 col-sm-15">
        <div class="card">
            <div class="header">

     <div class="panel panel-default m-t-11" style="">

      <div class="panel-heading"><i class="fab fa-google"></i> Google Sıra Bulucu</div>
      <div class="panel-body">

   

    
          <div class="message"></div>

          <div class="form-group">
		  <form action="" method="post">
            <label>Alan Adi</label>
            <input type="text" name="alanadi" id="alanadi" class="form-control" value="google.com.tr" autocapitalize="off">
          </div>

       
    
      
<div class="form-group">
            <label>Anahtar Kelime</label>
            <input type="text" name="anahtarkelime" id="anahtarkelime" class="form-control" value="anahtar kelime" autocapitalize="off">
          </div>
        

       
       

          <div class="form-group">
          <label>Ülke Seçiniz</label> 
                <select name="ulke" class="form-control" id="ulke">
                                   <option value="Turkey">Türkiye</option>
                            
                                </select>
           </div>



          <div class="form-group">
            <button type="submit" name="Gonder" class="btn btn-primary btn-round">
              Kontrol Et
            </button>

          </div>
        </form>

       </div> 