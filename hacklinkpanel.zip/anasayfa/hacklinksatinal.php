<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>


<?php
$kredi++;
$kredi = $sonucbilgi["kredi"];
?>
<?php if($sonucbilgi["kredi"]>=$_GET['fiyat']) {?>

<?php
if (isset($_POST["Gonder"])) {
$gonderenid = $_SESSION['user_id'];
$fiyat=$_POST['fiyat'];
$bakiye=$sonucbilgi["kredi"];
$ybakiye=$bakiye-$fiyat;
$guncelle = $conn->prepare("UPDATE kullanicilar SET kredi=:kredi WHERE id=:id ");
 
$guncelle->execute(array(':kredi'=>$ybakiye , ':id'=>$gonderenid));
 
if($guncelle){
 
echo '<div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>HackLink Başari İle Satin Alindi!</strong>
                </div>';
 
}else{
 
echo "başarısız";
 
}

}

?>

<?php
if (isset($_POST["Gonder"])) {	
$gonderenid = $_SESSION['user_id'];
$ip = $_POST['ip'];
$log = $_POST['log'];
$sql = "INSERT INTO hacklinkler (alanid, ip, log) VALUES (:alanid, :ip, :log)";
$gonder = $conn->prepare($sql);
$gonder->bindParam(':alanid', $gonderenid);
$gonder->bindParam(':ip', $ip);
$gonder->bindParam(':log', $log);
$gonder->execute();
}

?>
   <div class="col-md-12">
              

     
	 <body class="theme-purple">
    <div class="col-lg-15 col-md-15 col-sm-15">
        <div class="card">
            <div class="header">

     <div class="panel panel-default m-t-11" style="">

      <div class="panel-body">

   

    
          <div class="message"></div>

          <div class="form-group">
		  <form action="" method="post">
            <label>Alan Adiniz</label>
            <input type="text" name="log" id="log" class="form-control" value="Alan Adiniz" autocapitalize="off">
            <input type="hidden" name="fiyat" id="fiyat" class="form-control" value="<?php echo $_GET['fiyat']; ?>" autocapitalize="off">
          </div>

       
    
      
<div class="form-group">
            <label>İP Adresiniz</label>
            <input type="text" name="ip" id="ip" class="form-control" value="İP Adresiniz" autocapitalize="off">
          </div>
        
<div class="form-group">
            <label>Anahtar Kelimeler</label>
            <input type="text" name="anahtarkelime" id="anahtarkelime" class="form-control" value="Anahtar Kelime" autocapitalize="off">
          </div>
       
       




          <div class="form-group">
            <button type="submit" name="Gonder" class="btn btn-primary btn-round">
              Satin Al
            </button>

          </div>
        </form>

       </div> 
	   
	   
	   <?php } else{ echo '<div class="alert alert-dismissible alert-danger">
                        
                        <strong>Krediniz Bulunamadi,</strong> Lütfen Kredi Yükle Bölümünden Kredi Yükleyiniz!
                </div>'; } ?>