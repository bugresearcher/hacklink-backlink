<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>


     

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Tablo</strong> <small>Destek Talepleri</small> </h2>                        
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Talep Başlığı</th>
                                    <th>Talep Durumu</th>
                                    <th>Tarih</th>
									<th>İşlem</th>
                                </tr>
                            </thead>
							
					
<?php 

$numara1 = $_SESSION['user_id'];
$verial1 = $conn -> prepare("SELECT * FROM destektalepleri WHERE alanid = :alanid");
$verial1->bindParam(':alanid', $numara1);
$verial1-> execute();
while($goster = $verial1->fetch(PDO::FETCH_ASSOC)){
    $id = $goster['id'];
    $baslik = $goster['baslik'];
    $durum = $goster['durum'];
    $tarih = $goster['tarih'];
    $durum = $goster['durum'];
	 if($durum=="") {

                        echo "Durum Yok ";

                } elseif ($durum=="1") {

                        $durum2 = "<a class='btn btn-danger btn-round btn-simple hidden-xs m-l-10'>Yönetici Cevabı Bekleniyor ! </a>";

                } elseif ($durum=="2") {

                        $durum2 = "<a class='btn btn-success btn-round btn-simple hidden-xs m-l-4'>Destek Talebi Cevaplandi ! </a>";

                }else

                        $durum2 = "Geçersiz ";
						


?>
                            <tbody>
                                <tr>
                                    <td><?php echo $id; ?></td>
                                    <td><?php echo $baslik; ?></td>
                                    <td><?php echo $durum2; ?></td>
                                    <td><?php echo $tarih; ?></td>
									<td><a href="?sayfa=destekgoruntule&numara=<?php echo $id; ?>" class="btn btn-primary btn-round btn-simple hidden-xs m-l-10">Yönet </a></td>
                                </tr>                           
                            </tbody>
<?php } ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>