	<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>

<?php 

$vericek = $conn -> prepare("SELECT * FROM kullanicilar where id = :id");
$vericek->bindParam(':id', $_SESSION['user_id']);
$vericek-> execute();
$veriyigoster = $vericek -> fetch(PDO::FETCH_ASSOC);



?>

<?php
if (isset($_POST["Gonder"])) {
	
$ids = $_SESSION['user_id'];
$adiniz = $_POST['adiniz'];
$email = $_POST['email'];
$kullaniciadi = $_POST['kullaniciadi'];
$guncelle = $conn -> prepare("UPDATE kullanicilar SET isim=:isim, email=:email, kullaniciadi=:kullaniciadi WHERE id=:id");
$guncelle->bindParam(':id', $ids);
$guncelle->bindParam(':isim', $adiniz);
$guncelle->bindParam(':email', $email);
$guncelle->bindParam(':kullaniciadi', $kullaniciadi);
$guncelle-> execute(); 
if($guncelle){
 
$mesaj = '<div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>HESABİNİZ BAŞARILI BİR ŞEKİLDE GÜNCELLENDİ!</strong>
                </div>';
 
}else{
 
$mesaj = "başarısız";
 
}

}

?>

<div class="card">
                    <div class="header">


<div class="col-md-12">

       <div class="panel panel-default" style="margin-bottom:30px;">
         <div class="panel-heading" style="margin-bottom:5px;background:#fff;border-color:#34495e;color:#34495e">Hesap Bilgilerim</div>

          <div class="panel-body" style="padding:15px 15px 15px 15px;">

  

        
     <form action="" method="post">

     <div class="message"></div>

	 <?php if(!empty($mesaj)): ?>
		<p><?= $mesaj ?></p>
	<?php endif; ?>

     <div class="deploy">

<div class="form-group">
                     <label for="inputEmail3" class="">Adıniz</label>
                     <input type="text" name="adiniz" class="form-control" id="adiniz" value="<?php echo $veriyigoster['isim']; ?>">
					 <input type="hidden" name="id" class="form-control" id="id" value="<?php echo $_SESSION['user_id']; ?>">
                  </div>
        
          <div class="form-group">
                     <label for="inputEmail3" class="">Kullanici Adiniz</label>
                     <input type="text" name="kullaniciadi" class="form-control" id="kullaniciadi" value="<?php echo $veriyigoster['kullaniciadi']; ?>">
                  </div>
     

         
          <div class="form-group">
                     <label for="inputEmail3" class="">E-Mailiniz</label>
                     <input type="text" name="email" class="form-control" id="email" value="<?php echo $veriyigoster['email']; ?>">
                  </div>

         
        <div class="form-group">
                     <label for="inputEmail3" class="">Şifreniz</label>
                     <input type="text" name="sifreniz" class="form-control" id="sifreniz" value="Sifreniz">
                  </div>
         

         
        

         
       


       </div>   




 <hr>
  <a href="?sayfa=anasayfa" class="btn btn-danger pull-left">
         Geri Dön
  </a>
  <button type="submit" name="Gonder" class="btn btn-success pull-right">
         Kaydet
  </button>
</div>


</div>
   
</form>