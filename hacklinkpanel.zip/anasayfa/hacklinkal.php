<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>


     


       <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Tablo</strong> <small>Hacklink Panel Yönetimi</small> </h2>                        
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                       
							
					

                            <tbody>
                                <tr>
                                    <td>1 URL</td>
                                    <td>5 Anahtar Kelime</td>
									<td>+2000 Backlink</td>
                                    <td>500 SOSYAL LİNK</td>
                                    <td>Sayfada SEO Denetimi</td>
									<td>Rakip analizi</td>
									<td>Stratejik Oyun Planı</td>
									<td>30 GÜN İADE</td>
									<td>25 TRY</td>
                                    <td><a href="?sayfa=hacklinksatinal&fiyat=25" class="btn btn-primary btn-round btn-simple hidden-xs m-l-10">Satın Al </a></td>
                                </tr>  

                                <tr>
                                    <td>2 URL</td>
                                    <td>15 Anahtar Kelime</td>
									<td>+5000 Backlink</td>
                                    <td>1000 SOSYAL LİNK</td>
                                    <td>Sayfada SEO Denetimi</td>
									<td>Rakip analizi</td>
									<td>Stratejik Oyun Planı</td>
									<td>30 GÜN İADE</td>
									<td>50 TRY</td>
                                    <td><a href="?sayfa=hacklinksatinal&fiyat=50" class="btn btn-primary btn-round btn-simple hidden-xs m-l-10">Satın Al </a></td>
                                </tr>  	

                                  <tr>
                                    <td>10 URL</td>
                                    <td>50 Anahtar Kelime</td>
									<td>10000 Backlink</td>
                                    <td>2000 SOSYAL LİNK</td>
                                    <td>Sayfada SEO Denetimi</td>
									<td>Rakip analizi</td>
									<td>Stratejik Oyun Planı</td>
									<td>30 GÜN İADE</td>
									<td>150 TRY</td>
                                    <td><a href="?sayfa=hacklinksatinal&fiyat=150" class="btn btn-primary btn-round btn-simple hidden-xs m-l-10">Satın Al </a></td>
                                </tr> 
								
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>