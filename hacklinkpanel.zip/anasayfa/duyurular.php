<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['user_id']) && !empty($_SESSION['user_id']) ){

	$bilgiler = $conn->prepare('SELECT * FROM kullanicilar WHERE id = :id');
	$bilgiler->bindParam(':id', $_SESSION['user_id']);
	$bilgiler->execute();
	$sonucbilgi = $bilgiler->fetch(PDO::FETCH_ASSOC);

	$kullanicii = NULL;

	if( count($sonucbilgi) > 0){
		$kullanicii = $sonucbilgi;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>


     

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Tablo</strong> <small>Duyurular</small> </h2>                        
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Duyuru Başlığı</th>
                                    <th>Duyuru İçeriği</th>
                                    <th>Tarih</th>
									<th>Yazar</th>
                                </tr>
                            </thead>
							
					
<?php 

$verial1 = $conn -> prepare("SELECT * FROM duyurular");
$verial1-> execute();
while($goster = $verial1->fetch(PDO::FETCH_ASSOC)){
    $id = $goster['id'];
    $baslik = $goster['baslik'];
    $icerik = $goster['icerik'];
    $tarih = $goster['tarih'];
    $yazar = $goster['yazar'];

?>
                            <tbody>
                                <tr>
                                    <td><?php echo $id; ?></td>
                                    <td><?php echo $baslik; ?></td>
                                    <td><?php echo $icerik; ?></td>
                                    <td><?php echo $tarih; ?></td>
									<td><?php echo $yazar; ?></td>
                                </tr>                           
                            </tbody>
<?php } ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>